# AC evidence matrix
Q1 planning only. No independent acceptance verdict.

| AC | Planned test | Q2 status |
|---|---|---|
| AC-01 | T01 | NOT RUN |
| AC-02 | T02 | NOT RUN |
| AC-03 | T03 | NOT RUN |
| AC-04 | T04 | NOT RUN |
| AC-05 | T05 | NOT RUN |
| AC-06 | T06 | NOT RUN |
| AC-07 | T07 | NOT RUN |
| AC-08 | T08 | NOT RUN |
| AC-09 | T09 | NOT RUN |
| AC-10 | T10 | NOT RUN |
| AC-11 | T11 | NOT RUN |
| AC-12 | T12 | NOT RUN |
| AC-13 | T13 | NOT RUN |
| AC-14 | T14 | NOT RUN |
| AC-15 | T15 | NOT RUN |
| AC-16 | T16 | NOT RUN |
| AC-17 | T17 | NOT RUN |
| AC-18 | T18 | NOT RUN |
| AC-19 | T19 | NOT RUN |
| AC-20 | T20 | NOT RUN |
| AC-21 | T21 | NOT RUN |
| AC-22 | T22 | NOT RUN |
| AC-23 | T23 | NOT RUN |
| AC-24 | T24 | NOT RUN |
| AC-25 | T25 | NOT RUN |
| AC-26 | T26 | NOT RUN |
| AC-27 | T27 | NOT RUN |
| AC-28 | T28 | NOT RUN |
| AC-29 | T29 | NOT RUN |
| AC-30 | T30 | NOT RUN — Director/Architect judgment |
