# QAM state
Phase: AWAITING_LEAD — Q1 returned with environment incident and gaps.
Attempt: Q1_001. Executor: Cody. Candidate/execution HEAD: 94251beab08dd26d7f56f4b8f2299a1e841892c5
Branch: qa/ffm-abm-001-subscription-portal
Plan: QAM_TEST_PLAN.md v1; SHA-256 42ebdbc6ac88ddf6733416aaa0374be1cc852400a6f1679ca631891ef7ddc24d
Contract: ACCEPTANCE_SPEC v1.1 + active subject contracts + R-001–R-009.
Lead approval: NONE. Director Q2 release: NONE. Q2: NOT RUN.
Latest package: HANDOFFS/FFM-ABM-001-SUBSCRIPTION-PORTAL_Q1_REVIEW_001.zip
Next owner: QA Lead reviews recon/plan/findings; Director supplies release only after approval.
Build incident: Q1-ENV-001; existing-server continuity unverified. No product repair or Git mutation.
