# Q1 findings / observations
No independent product verdict. Lead owns classification/severity.

- Q1-ENV-001 — observed QA execution error: initial build ran in repo and replaced .next while existing :3457 server was listening. Source unchanged; continuity unverified. Director operational disposition needed; no unsolicited restart. Isolated webpack build followed. Evidence: recon and build logs.
- Q1-ENV-002 — isolated default Turbopack build rejected external node_modules symlink. Setup issue; webpack fallback succeeded. Q2 default build needs local dependency copy/install.
- Q1-OBS-001 — Tony reports Advance 31 minutes appears inert. Engine offset wiring observed; UI behavior untested. T09/T29 checks effect and feedback separately; no repair in Q1.
- Q1-RISK-001 — inherited global logout can revoke Tony's same-account sessions. No Q1 logout; final Q2 logout explicitly planned.
- Q1-GAP-001 — configured auth target host shape verified, independent project/credential-rotation provenance not established. Director to confirm existing authorized shared-dev configuration/identity remains suitable; no secret disclosure needed.
- Q1-GAP-002 — final account-pill layout, true zoom, relevant rendered contrast and server-side egress remain independent Q2 work; engineering greens do not close them.

- STOP-AUTH — Q1, 2026-10-28T06:45:29Z, candidate 94251beab08dd26d7f56f4b8f2299a1e841892c5: one real login attempt failed to reach dashboard within 20 seconds. Cause undetermined; raw error suppressed. Affected: real-auth and protected-browser readiness. Owner: Director for identity/target validity, Executor for bounded instrument diagnosis after disposition. Resume with bounded login, then approved Q2; never label live checks PASS. Evidence: evidence/q1/probe.json.
