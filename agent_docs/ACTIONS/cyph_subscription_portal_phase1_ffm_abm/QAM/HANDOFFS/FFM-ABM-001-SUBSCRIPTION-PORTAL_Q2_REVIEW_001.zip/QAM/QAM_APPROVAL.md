# Q2 approval and release — 28 October 2026
QA Lead JARVIS: APPROVED WITH EXACT EXECUTION AMENDMENTS. Director Tony issuing current chat dispatch releases Q2.
Product candidate: 94251beab08dd26d7f56f4b8f2299a1e841892c5
Branch: qa/ffm-abm-001-subscription-portal
Approved unchanged QAM_TEST_PLAN.md SHA-256: 42ebdbc6ac88ddf6733416aaa0374be1cc852400a6f1679ca631891ef7ddc24d
Assignment: reviewed plan plus current dispatch. Supersedes HOLD/additional Q1 assignment in CYPH_Q1_LEAD_DECISION_001_2026-10-28.md; preserve history. No additional Q1 approval/package.

## Binding execution amendments
1. Verify candidate, branch/current changes; distinguish approved product SHA from docs-only execution HEAD. Product/config/test drift must be reported rather than tested under old identity.
2. Opening same-run setup: owned isolated clean build/server, existing lock/dependencies physically inside scratch root, explicit CWD checks. Never build live repo/disturb unrelated servers; preserve earlier incident/failed attempts.
3. Execute T01–T29/regression continuously, detailed matrix; all mapped journeys/states, both themes, responsive boundaries/final pills, access/quote/consent/idempotency/recovery. Member/superadmin controlled-role evidence labelled mocked.
4. Source/import/diff and appropriate browser/server runtime evidence for mock-only business boundary. Existing shared-dev auth/read-only role lookup permitted; no live Stripe/email/provisioning/business writes. Disclose instrument limits.
5. Keyboard/focus/rendered contrast/actual browser 200% zoom. Never substitute half-width or device scale. Group exact human assistance needs near end, pending until evidence; complete safe independent checks.
6. Authorized admin credentials helper-only, no credentials/tokens/auth state in app/build environment/logs/screenshots/exports. Avoid unsafe inherited storage hooks/extra logout. Tony informed GLOBAL logout can end other sessions; perform once, last.
7. Correct disposable QA helpers with failure/correction evidence. No product repair, weakened assertions or retry merely for green; record failures and continue unaffected checks.
Continuous run; no routine milestones/plan pauses. Stop affected work only for genuine identity/target/auth/privacy/authority/instrument blocker. AC-30 pending Director ride/Architect closeout after Lead assessment, not an export blocker. One complete results ZIP and identical Downloads copy, then STOP for Lead adjudication/certification. No Git/account/role/deploy mutation or self-certification.
Login resolution Director-reported; verify independently in Q2.
