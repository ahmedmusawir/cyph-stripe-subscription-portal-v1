# REPAIR_006 consolidated coverage

Manifest f7181d3c7c537e27ebc43403c8727a39084aae723ba895cb89acf7622d56e9ab; finalizedplan 9017fa6d39d86091da0a7ef7efac791be33eea4af816d568f1a5f28f6df4d987. Detailed27executedbrowser titles/results and85service controls in evidence/repair006. Prior matrix preserved in AUTOMATION/repair006/prior-AC_EVIDENCE_MATRIX.md.

| Scope | Result | Evidence / limit |
|---|---|---|
| R6-01 / R5-F01 / AC10,11,13 | PASS observed | 5originalreader cases;3missing-scope controls,recordedamountonly,setup/email unknown preserved,normalpaid tracks,terminalrecovery,guards/reload |
| R6-02 / R5-F02 / AC11,12 | PASS observed | 4originalresendnegatives;85independent reader/resendcontrols;28reader agreements;validsent/failed resends;refusalsobject+deepstateunchanged |
| R6-03 / consumer consistency | PASS bounded audit | ASTfunction/globalcomparison,inventory/facade review,7-inputdelta;corephase/scope/key/allocationwriters unchanged;affectedActivationconsumer rerun |
| R6-04 / AC05,06,06a,08,09,27 | PASS current gates / documented reuse | Cleanbuild/producttypecheck;13suites248Jest;19focused+5original+3neighborbrowserPASS;changedR012assertionchecked andsafeguardsrerun;independent224matrix/legacy/21stores reused withprovenance |
| R6-05 / AC21–23 | PASS sampled | 375/1440both themes;8actual200%Chrome checks;187applicablecontrastsamples0shortfalls;keyboardmainentry/terminalrecovery;unchangedstyles reused |
| AC01–03,15–19,24–26 | REUSED unaffected + current mocked unit gates | Account/auth/routes/styles/dependencies unchanged;priorrealadmin/Retry/StripeHTML-RSC applicable;0sign-ins/logout;C08excluded perLead |
| R5-O03 | FAILED strict assertion / ACCEPTED NONBLOCKING | Originalfailure preserved;new5repeat deepmaterialeffects checkPASS;not repaired,no newmaterialeffect |
| AC28 | PACKAGE VALIDATION | Manifest/plan/dispositions/attempts/coverage/index/memberhash/CRC/privacycontrols+identicalcopy asserted |
| AC30 | DIRECTOR ACCEPTANCE RECORDED; LEAD/ARCHITECT PENDING | No duplicate ride,no certification;Coachconfirmationspending |
