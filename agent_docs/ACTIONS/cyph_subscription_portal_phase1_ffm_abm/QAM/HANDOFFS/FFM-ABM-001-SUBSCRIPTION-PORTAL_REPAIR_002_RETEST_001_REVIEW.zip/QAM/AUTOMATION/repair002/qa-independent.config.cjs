module.exports={...require('./jest.config.js'),roots:['<rootDir>/qa-independent'],testMatch:['**/*.test.ts']};
