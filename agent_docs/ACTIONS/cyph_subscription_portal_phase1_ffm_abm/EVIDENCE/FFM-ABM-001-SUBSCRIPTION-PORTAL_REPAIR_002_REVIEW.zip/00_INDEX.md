# FFM-ABM-001-SUBSCRIPTION-PORTAL — REPAIR_002 review package index (RULINGS R-012)

Engineering repair of independent Gate Q failures CR-F01 / CR-F02 (+ Q2-O04 residual, self-found R2-N01/R2-N02). Engineering self-checks only — not QA certification.
Branch `qa/ffm-abm-001-subscription-portal`, starting candidate `24cf075dc3c6252bc22712b067cbf9a8680f24fa`; repair uncommitted, pending Director commit.
Start with `REPAIR_002_ENGINEERING_REPORT.md`. Machine index: `FILE_INDEX.json` (every member except itself).

| Member | Role | Bytes | SHA-256 |
|---|---|---|---|
| `REPAIR_002/CHANGED_PATHS.txt` | report/inventory | 4007 | `c8e3f16d7619706d2aa7243f3a755c130b961131ab085f28caa66fd756c2b95e` |
| `REPAIR_002/CLEANUP_REPORT.md` | report/inventory | 1320 | `da23fc329215b2f7986ca55a6934b190e3e56320af169cec67e4b29e1b049a7c` |
| `REPAIR_002/REPAIR_002_product.diff` | scoped diff vs 24cf075 | 74971 | `19605a5a4521126f4584881f4be05352f7c854e083bffda413656223d08bf4a1` |
| `REPAIR_002/REPAIR_002_records.diff` | scoped diff vs 24cf075 | 30827 | `7d2f12eb919b12e465e8bd4abd06264eed24dc034ae20c370f2008a59a4c288f` |
| `REPAIR_002/before/before-A-activation.png` | before-repair reproduction (24cf075) | 68771 | `795847d66f7fcb65525ae1c8c50f1af014a5b1c9dfc87b75689100979c0a2a98` |
| `REPAIR_002/before/before-A-current-ui.json` | before-repair reproduction (24cf075) | 276 | `5aef72944225f19ceb6a45d93e8f8d86263bb9331c4edb0453fbea91b4e51636` |
| `REPAIR_002/before/before-B-legacy-browser.json` | before-repair reproduction (24cf075) | 152 | `75a98f326ef21fb87dc3c069239c0b1c0b0b8b8667134b624a96a31d41024c0e` |
| `REPAIR_002/before/before-C-edit-while-open.json` | before-repair reproduction (24cf075) | 302 | `86b7df129b9c946007fda40568c75d83d80c0df160df2b5599ec66e1f6a8d2a7` |
| `REPAIR_002/before/before-jest-new.json` | before-repair reproduction (24cf075) | 213152 | `6a6a6d8ec184ab5b7c695b23ad9e345a7b67dea92fe3cd3655897d9eca47bfaf` |
| `REPAIR_002/before/before-service.json` | before-repair reproduction (24cf075) | 687 | `3af7b9c6a3566ace410ba259c1cb2928e47f088e58e7b1b284cee4b7810d1870` |
| `REPAIR_002/data/contrast-repair002.jsonl` | measured data | 26016 | `067336d3598253e2d25cb824d6e9b663c2876190242e9fc361baf9f6864e4ac1` |
| `REPAIR_002/data/gate-m-account.jsonl` | measured data | 9624 | `93f1125a06b111b093a76e118ff03a79248ce0633aabc82a258c96d9b683c6fd` |
| `REPAIR_002/data/gate-m-public.jsonl` | measured data | 16024 | `e1119d5d05ce3f21fe21960549e6592e89ae51f6c3393b8d23dfd69180b60f0b` |
| `REPAIR_002/data/gate-m-repair002.jsonl` | measured data | 2064 | `82e20131dbf42b8245af65db9521722260ed594983cd3392c398f67544487664` |
| `REPAIR_002/data/jest.json` | measured data | 75116 | `49b9165177320391118f751bb012b9d9c77e2a5987e310bc3fb65cbdd66950e8` |
| `REPAIR_002/data/repair-contrast-account.jsonl` | measured data | 70924 | `60b1efe1315fb0b0e5ddee8eebb781fc12844a41c2ceabc0763273e667ebfdd7` |
| `REPAIR_002/data/repair-contrast-public.jsonl` | measured data | 131371 | `66ca46ffcd4561be53046a9ff3b5f51743309ca74e507d44910144273d04908e` |
| `REPAIR_002/data/signin-count.txt` | measured data | 33 | `6e1b912d1649e6400f34db1706f76111b6b0247de4f48632c8681b58a547e2f2` |
| `REPAIR_002/logs/base-build.log` | command log | 1251 | `40249746127908bd62d4936cf033143f76067674168d207bab3e63c200f43191` |
| `REPAIR_002/logs/before-browser.log` | command log | 427 | `7866e8b746fe8010d1c935fb8f6d156402ca360e764520b634e2142e4c3649b7` |
| `REPAIR_002/logs/before-jest-new-attempt1-OOM.log` | command log | 3233 | `2309723d1451028d2f2de5c8e26d24f47593ddc58cae1a81966900dff4ee5a4b` |
| `REPAIR_002/logs/before-jest-new.log` | command log | 55962 | `c6037594f101a73a908696e837d913f4fc19c52d1c821c4b89a4c5c338227c97` |
| `REPAIR_002/logs/before-regression-spec.log` | command log | 17654 | `064e67d3554d7905a21d5584d15cd0bac34504ded4422beb6727ac0e0d272a8a` |
| `REPAIR_002/logs/build.log` | command log | 1251 | `5908b84261aa5572ba1beb2b0fa8e3de4f7f29fa9f32b5eddd9716eb4e192905` |
| `REPAIR_002/logs/jest.log` | command log | 323 | `fd516440a9b70ad0470a0ecc4a35b38eff20814005a43693f86f75aa77b735a9` |
| `REPAIR_002/logs/pw-account-1.log` | command log | 4612 | `bd12559310919859c0a5e01665862594c95d9e2ee65ff4b3bd4f2816015126f4` |
| `REPAIR_002/logs/pw-public-1.log` | command log | 15816 | `e189b55b86623110cc49b18f2c10b061a4c363ff0fb80d816a76478d75138e94` |
| `REPAIR_002/logs/pw-repair002-1.log` | command log | 6953 | `fb491967c96349e0b8eb272309cc4e5f4a934a7cb2c23750d09c7650d7007094` |
| `REPAIR_002/logs/pw-surfaces-2.log` | command log | 627 | `3ed1a38357fe8909172eab5b400f728f9464a3e97681bf74d0eb14e5c4581de5` |
| `REPAIR_002/logs/tsc.log` | command log | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `REPAIR_002/repro/public.repro002.spec.ts` | baseline reproduction script (not committed product) | 4151 | `12fa1f321b3c668ab74997632fab7de2b8bec1d4220980d1b5d0f27c9ba05d20` |
| `REPAIR_002/repro/repro002.test.ts` | baseline reproduction script (not committed product) | 3513 | `9822c13aa4a2fd483d1aa46194943cceee2930a9f254f9f6be2971840566059c` |
| `REPAIR_002/screenshots/REFERENCE_approved_account-billing__active_mist__mobile.png` | approved design reference render | 459872 | `e401cfa87e2c58427b8e813552a0859bdee73aa6a28251b20d3a878f31958051` |
| `REPAIR_002/screenshots/repair002-account-billing_active_dark_desktop.png` | screenshot (synthetic data; account identity masked) | 154572 | `0ed744329e7bcadaa0e2f43d614dffd4362562d44873e686573f1334ac8bb6ac` |
| `REPAIR_002/screenshots/repair002-account-billing_active_dark_mobile.png` | screenshot (synthetic data; account identity masked) | 143697 | `7826a57eea99c2f91ad86ca7d5330b739a0f6ba651f02c52b38884948b6d9864` |
| `REPAIR_002/screenshots/repair002-account-billing_active_light_desktop.png` | screenshot (synthetic data; account identity masked) | 156869 | `4bff0863e2302ab385a8b4cce4b20322d73814c50748c33d2a4493aee4c5ed0f` |
| `REPAIR_002/screenshots/repair002-account-billing_active_light_mobile.png` | screenshot (synthetic data; account identity masked) | 145075 | `6ac76abdd84662f161fbebc3643efbacc877ddd05d28d3f71f39d1a26aedd591` |
| `REPAIR_002/screenshots/repair002-activation-hold_dark_1440.png` | screenshot (synthetic data; account identity masked) | 88588 | `91b2e99e81166a75b6344617cfab6d401e16ba01766c92c8d5a5bf86ef8e5d14` |
| `REPAIR_002/screenshots/repair002-activation-hold_dark_375.png` | screenshot (synthetic data; account identity masked) | 77992 | `9edb2831c7d6d610369cec5520fbea0225595db31788685873338d77d13f3076` |
| `REPAIR_002/screenshots/repair002-activation-hold_light_1440.png` | screenshot (synthetic data; account identity masked) | 88713 | `1d5910e795c9c0dd6279d8317b3725231371d578925613842e98df85cae80f40` |
| `REPAIR_002/screenshots/repair002-activation-hold_light_375.png` | screenshot (synthetic data; account identity masked) | 77999 | `8c5ab7c7f50ed346fb207300cc00f9dfce5d165eba768ee9f039da0100dc9dc6` |
| `REPAIR_002/screenshots/repair002-stand-in-closed_dark_1440.png` | screenshot (synthetic data; account identity masked) | 38567 | `9843d2f11d9e4ceca117288dbb9e0acea439e6b77f7414e3fd19b912e6bdd4bb` |
| `REPAIR_002/screenshots/repair002-stand-in-closed_dark_375.png` | screenshot (synthetic data; account identity masked) | 33744 | `7e35b40a3987ad3ad831bbb90cda91cb9d652ebb1b83464233ab995a99b56b3f` |
| `REPAIR_002/screenshots/repair002-stand-in-closed_light_1440.png` | screenshot (synthetic data; account identity masked) | 38493 | `8f02fe892f6f970876f4bc71ecd1457fe449c90f22695e3378554058d7bb4104` |
| `REPAIR_002/screenshots/repair002-stand-in-closed_light_375.png` | screenshot (synthetic data; account identity masked) | 33678 | `2606dd81186df330ce2667f2874dae92400737dfb93188cd1507d0791e13bccc` |
| `REPAIR_002/screenshots/repair002-stand-in-hold_dark_1440.png` | screenshot (synthetic data; account identity masked) | 37933 | `2df58beb5bcbd001e7375fb02ed74e86343a6a56f9e9bda83dcd126af0b4054e` |
| `REPAIR_002/screenshots/repair002-stand-in-hold_dark_375.png` | screenshot (synthetic data; account identity masked) | 34019 | `0775f23eadb65aa8a3b13b581cd3e6a2c0e80240e5702f6ebda5c60ee3e9a362` |
| `REPAIR_002/screenshots/repair002-stand-in-hold_light_1440.png` | screenshot (synthetic data; account identity masked) | 37886 | `c34425c81df02bc13969ce31cb2d5ec625830b961b1e3ae96780d404fae6e2ac` |
| `REPAIR_002/screenshots/repair002-stand-in-hold_light_375.png` | screenshot (synthetic data; account identity masked) | 33869 | `b11597d5db07150714c37824d39ec9d1b2eaf70ad6d95e5246846e4c75a432e7` |
| `REPAIR_002/screenshots/repair002-unknown-hold_dark_1440.png` | screenshot (synthetic data; account identity masked) | 112559 | `e695d8d77b3adf9ef26a905629da56b9e345b98f1f3411c9d11cb1a3ac88826d` |
| `REPAIR_002/screenshots/repair002-unknown-hold_dark_375.png` | screenshot (synthetic data; account identity masked) | 100893 | `6c63b7cc57710cb2e5f1ed353b09384a7c6faca7ff521942c0e61ccf33d0cd44` |
| `REPAIR_002/screenshots/repair002-unknown-hold_light_1440.png` | screenshot (synthetic data; account identity masked) | 112276 | `98b84f7f48ba90630ac33e804c85e749c1923bebe86ee992ffc5e96042a4ae69` |
| `REPAIR_002/screenshots/repair002-unknown-hold_light_375.png` | screenshot (synthetic data; account identity masked) | 100572 | `04eac05ec0c0f9b9bae5b320ea5e07312a6d251f1e5288db7eb5fd3935e8c0b1` |
| `REPAIR_002_ENGINEERING_REPORT.md` | report/inventory | 19023 | `70a4d4428cbf0471d2dca051429a4fe026df8631ee97626d7843245361320849` |
| `records/ACCEPTANCE_LEDGER.md` | record copy | 7592 | `2a4ca6cffe2645c15dd4236462123460a08261903c70c0feeb08cca50a488739` |
| `records/ACCEPTANCE_SPEC.md` | record copy | 17835 | `0809401e42733510753df133f4eeba84ad62190e7c9f2be9d9fc9d9a88d49c79` |
| `records/CHANGELOG.md` | record copy | 3726 | `e921609ac2d1fc61df1538da6f0e0d2ef7ca7bb2c0e5fb0a7847cbde3ac7a6fd` |
| `records/JOURNAL.md` | record copy | 6870 | `04ce65236ab33ce84d30c149e331c71df7073ff42ca03e45e9bcd78076f1fbff` |
| `records/QAM/ENGINEERING_HANDOFF.md` | record copy | 7335 | `66c806b753b748512de4015569aceb0eeacf8410cd813888b0dba4cbbdb95eab` |
| `records/RECOVERY.md` | record copy | 5538 | `94fe757c7a7f2d6e949b3c6e0fe0cdadded0cb65b738d417b9c874c2f561035d` |
| `records/RULINGS.md` | record copy | 26552 | `2da94e0bcd4c6104453aef98a7e187edb4d56c9feeda8e0004d5c482ce48cd10` |
| `records/STATE.md` | record copy | 6927 | `575710e9e13a1d3428dacb07b2199a4d6085ec83b5ee5c8f1b8ff97dd92afc28` |
| `records/_project/DATA_CONTRACT.md` | record copy | 18779 | `0716594b2948c01c9e0c9a85431951cd2f9472ac0a51220fc410fdfadca7d938` |
| `records/_project/UI_SPEC.md` | record copy | 22653 | `ce533881a7c0a93820244b638d8b42aad6ac075da692d8e20623661d5c8cff0e` |
| `records/session_2026-10-29.md` | record copy | 4767 | `413be427a39b25489a47d8ea4b7b86ef93d507c9cf07d9e6b46d9bfaa85f7623` |
| `source/e2e/account.repair.spec.ts` | changed/new product or test file (working tree) | 18517 | `4f8dc59077b61c2073ac0500c5f000736d2b3a4cefa7c767dc0b95d02c328c49` |
| `source/e2e/public.repair002.spec.ts` | changed/new product or test file (working tree) | 21373 | `9c0ae358c7e3777581f1631f62dbbc4ff8e68c0a99a6e7ca216478eb342c7e36` |
| `source/src/__tests__/portal-checkout-hold.test.tsx` | changed/new product or test file (working tree) | 7206 | `0c19cc01b333e68261faf9724edecaddc0ba24f66c8b5a6f715bdf2e4b75a3ee` |
| `source/src/__tests__/portal-registration.test.ts` | changed/new product or test file (working tree) | 36437 | `3f3f236b0fe831fb4ec85491771c7a3c2e07447adb07d513b55f6ce116d9e36c` |
| `source/src/app/(public)/demo/register/pharmacies/page.tsx` | changed/new product or test file (working tree) | 807 | `d3505e61a350fd52aab785fe7856394eaf713ce93967c29364cee7ff251be589` |
| `source/src/components/portal/account/DashboardView.tsx` | changed/new product or test file (working tree) | 25495 | `803543272eb3e72c463a443965588abc4fbe9e7a2d2a599c631e399af1754cb9` |
| `source/src/components/portal/activation/ActivationView.tsx` | changed/new product or test file (working tree) | 12505 | `d4ba24d7008d0ee8dd4004e423c957600ffd5bc4c4bf205d1fd6c0ac14c686f0` |
| `source/src/components/portal/activation/CheckoutIncompleteView.tsx` | changed/new product or test file (working tree) | 7583 | `ae210d0f7dd81890a81243a17da46d9aacc5d216fe8e7bad39974b32d6077996` |
| `source/src/components/portal/handoff/CheckoutStandIn.tsx` | changed/new product or test file (working tree) | 11312 | `f139d6bcf6f25106255580ece79a2320caf3c8fbcc6b35ca1342c48f4a27ab81` |
| `source/src/components/portal/register/PharmacyStepView.tsx` | changed/new product or test file (working tree) | 6863 | `dcab8b8c8da97efd630e34818e46a67cafaf5e18f6a2cbf72c80dbabe4490623` |
| `source/src/components/portal/register/ReviewView.tsx` | changed/new product or test file (working tree) | 22004 | `09c9ad51b887919f91968b5215142542f529269bacb4d9d7a4a9f509323469eb` |
| `source/src/services/portal/index.ts` | changed/new product or test file (working tree) | 1459 | `91a2c4b439133ec254ca99bec47aab7735f9c163bce3040c54224456d76ff37a` |
| `source/src/services/portal/registration.ts` | changed/new product or test file (working tree) | 33183 | `6b1268d06fe19b2935325a1a2af4d6cd267b3cb89e3a6862d3599308ed5b8432` |
| `source/src/types/portal/state.ts` | changed/new product or test file (working tree) | 5499 | `5e9e722014b93054f176a3c31118d4261ef52787137f151edbc30b9999f7fecd` |
