# FFM-ABM-001-SUBSCRIPTION-PORTAL — REPAIR_002 addendum 2 package index (R-012 addendum 2)

Activation demo controls simplified: "Next activation check" removed; Registration scenario → Load is the single selector. Engineering self-check only — not QA certification.
Exact base: HEAD `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36` (Cody's retest candidate) + uncommitted ADDENDUM_001 (ZIP SHA-256 `f852ff94664b0e0a664582c213a8334d8b779758e3f8f2c8fbd88a4b1c0019e7`, unchanged). ADDENDUM_002 is uncommitted.
Start with `REPAIR_002_ENGINEERING_REPORT.md` §11 and `addendum_002/SCENARIO_RESULTS.md`. Machine index: `FILE_INDEX.json` (every member except itself).

| Member | Role | Bytes | SHA-256 |
|---|---|---|---|
| `REPAIR_002_ENGINEERING_REPORT.md` | report / results | 25873 | `362597c806778cfbc5ef762826aa8312549a757d5185b137be2384c90a7e0596` |
| `addendum_002/ADDENDUM_002_incremental.diff` | scoped incremental diff (ADDENDUM_002 only) | 16421 | `1efd3e6c36a0e36ffbe6722726c4bc3cd05d72ea961e108d0e73ce7fe5aa6f95` |
| `addendum_002/CLEANUP_AND_LIMITATIONS.md` | report / results | 1346 | `9317aff4d3df9cee19e658cf3a3c871cf9c5be316d8d1971599fbc0e572414a0` |
| `addendum_002/SCENARIO_RESULTS.md` | report / results | 3066 | `be4814b631aefcf0504ec45b852add695b5b1ba9fcdc000c85e255b91106d887` |
| `addendum_002/before/before-activation-plan-matrix.json` | before-change reproduction (d6fe678 + ADDENDUM_001) | 7886 | `08ac602b1c5431c9df40bbeb1bd93ec98e2471dedd5ee3eea30a90aec5856488` |
| `addendum_002/cumulative_vs_d6fe678.diff` | cumulative diff vs d6fe678 (ADDENDUM_001 + ADDENDUM_002) | 21607 | `a66d93f4c8640a7827fae7285e21336ac50707d368b6953b17d652468bde996c` |
| `addendum_002/data/activation-scenarios.jsonl` | measured data | 3010 | `4cb0ca959dd669b01a31c1471f3e301e5a37a72bd3883a5176e519fda538f959` |
| `addendum_002/data/contrast-activation-scenarios.jsonl` | measured data | 2220 | `02b71f051155d0b9826cbfc07200e9010d682ad6242e96f546dde82deeec9e45` |
| `addendum_002/data/contrast-repair002.jsonl` | measured data | 26016 | `26217f8e9c0d721ed0ef480fdb37e9b7138bcc81e6ca7ed8b106332a0710e995` |
| `addendum_002/data/gate-m-activation-scenarios.jsonl` | measured data | 3796 | `5d9449704e76c3ffd4649067906d3255fb5d94303fe5a4261da6317758b5d3e5` |
| `addendum_002/data/gate-m-public.jsonl` | measured data | 16024 | `e1119d5d05ce3f21fe21960549e6592e89ae51f6c3393b8d23dfd69180b60f0b` |
| `addendum_002/data/gate-m-repair002.jsonl` | measured data | 2064 | `82e20131dbf42b8245af65db9521722260ed594983cd3392c398f67544487664` |
| `addendum_002/data/jest-focused.json` | measured data | 34464 | `9b4f3d8ff55542724c68a306e8cfa6cda6f9b86efdc45cb7854a9faee0b65491` |
| `addendum_002/data/repair-contrast-public.jsonl` | measured data | 28364 | `69f8e203d2c0e9962dfa485497e87764a36c80bf342c899a866bea2ba7b50d27` |
| `addendum_002/logs/base-build.log` | command log | 1251 | `07ea5cd498a056752db7978fde3b4989217c4cfab809812f41d4a11efaac4148` |
| `addendum_002/logs/before-focused.log` | command log | 3409 | `000715983c2900d5ea3063220bd1f5c9a442e259792e2c7d3c87ba0d35132a5c` |
| `addendum_002/logs/before-repro.log` | command log | 177 | `18c900c0785411aa324714006ed2cda46d8665700a5f1fd5cde4ce82109722b0` |
| `addendum_002/logs/build.log` | command log | 1251 | `6dea557c7c1333d39daacd6e07e9e1fbf410e55e288fe48b115659e156268a68` |
| `addendum_002/logs/jest-focused.log` | command log | 411 | `75465cf6fc7e70e8bce3b2c461864554c3667e853e2d4f649ca339dd7ccd7f80` |
| `addendum_002/logs/pw-affected.log` | command log | 5163 | `fe5263cbe5a8a44826b05d40d57213ff968a0faf286a18c6ef912e4d161e32a1` |
| `addendum_002/logs/pw-focused.log` | command log | 1731 | `8106914bad55fd53451dfee1cace59b9796aca46a53e019a1e1501b34d86b4dc` |
| `addendum_002/logs/tsc.log` | command log | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `addendum_002/screenshots/activation_activation_delayed_dark_375.png` | screenshot (public screen, synthetic data) | 70892 | `8859cf60057d36039451378553311bd5b051abd521722cfff68b0ebec38db78a` |
| `addendum_002/screenshots/activation_activation_delayed_light_375.png` | screenshot (public screen, synthetic data) | 71232 | `91904a013693a8d6092ff4b7e1c876aa0c01a20b7d60cbf668033fd63402d2d1` |
| `addendum_002/screenshots/activation_activation_email_failed_dark_375.png` | screenshot (public screen, synthetic data) | 80025 | `5926cf8fa8ae457a621eac1a5c68534d36d8dc29fec194e8aceef9149ea7b624` |
| `addendum_002/screenshots/activation_activation_email_failed_light_375.png` | screenshot (public screen, synthetic data) | 80749 | `e45776e24094f2274f3b682b4edf906bb96df5290d86f7cc1b00874629ba8548` |
| `addendum_002/screenshots/activation_activation_payment_failed_dark_375.png` | screenshot (public screen, synthetic data) | 63945 | `6c342500d2ce953d89893dcaf546122aebe54eb40b68e20c464b17751b2fe807` |
| `addendum_002/screenshots/activation_activation_payment_failed_light_375.png` | screenshot (public screen, synthetic data) | 64315 | `d49d8d6516718884a6a82acdd09196334f5e16416cc9f5ffd2d89425f23ddb77` |
| `addendum_002/screenshots/activation_activation_provisioning_dark_375.png` | screenshot (public screen, synthetic data) | 59696 | `3c946bde00c8407b08231da93f28986c7e948242be1c56b8bcd740ea13924629` |
| `addendum_002/screenshots/activation_activation_provisioning_light_375.png` | screenshot (public screen, synthetic data) | 60226 | `0015feb62b0806e1aac7c4fe2112ae971669c6962954c0427f580ea204301197` |
| `addendum_002/screenshots/activation_activation_ready_dark_375.png` | screenshot (public screen, synthetic data) | 98105 | `d87a98625496c9d408a198acc1ccc430acfd8265b722dfe113511b3cc9b5b7c7` |
| `addendum_002/screenshots/activation_activation_ready_light_375.png` | screenshot (public screen, synthetic data) | 98871 | `be11540cd57d32505978d0400cd094b2fb13fd2f20cade2840e11be2316b4be8` |
| `addendum_002/screenshots/activation_activation_waiting_dark_375.png` | screenshot (public screen, synthetic data) | 67865 | `53666315f304c5815d25e8d8db8405fb59ae14cbac9dc926794bb927969a47c4` |
| `addendum_002/screenshots/activation_activation_waiting_light_375.png` | screenshot (public screen, synthetic data) | 67992 | `b5b34244b05c013cf8da52dcac78e6c03f84a0fc4dd477cf4fe8e60aaa2582fe` |
| `addendum_002/screenshots/demo-strip_dark_1440.png` | screenshot (public screen, synthetic data) | 26357 | `065fd9c02f42c0b3784460519950366c8cd5d3805c95e16d909dc6f1233fdd6a` |
| `addendum_002/screenshots/demo-strip_dark_375.png` | screenshot (public screen, synthetic data) | 27169 | `02ef5c21cdac2dd7ad4ac39826ddfc4b6ddb88d0a8cd6afb90723398c025d811` |
| `addendum_002/screenshots/demo-strip_light_1440.png` | screenshot (public screen, synthetic data) | 26401 | `52d4c0c851b832cff177bef28f3c098d0dd9f7f48bf4001821581b4bbd847537` |
| `addendum_002/screenshots/demo-strip_light_375.png` | screenshot (public screen, synthetic data) | 27300 | `b809dd890cc12da1ec22ae928f80fdd6f76c7ba7f26cc1d00ca0fdaeec264a36` |
| `records/CHANGELOG.md` | record copy | 5064 | `720843acae01e1376824c268e2543ddffbf38b27f80197e38e75a472c4fe31d7` |
| `records/JOURNAL.md` | record copy | 7513 | `e043f524d847950ea31e46232be5a2f76c54c4102f338a56ac4c536d193ece1b` |
| `records/QAM/ENGINEERING_HANDOFF.md` | record copy | 8466 | `dfb17fd5665aeaf600283f44a78424ef6ba649c800bfe0d1ee10a2336cda9d02` |
| `records/RECOVERY.md` | record copy | 7060 | `450bab571d538b745be75dc1a6529f782260dd8debd8d4eedbc1baaca361d085` |
| `records/RULINGS.md` | record copy | 29161 | `fe9317198395d9a39ed224804e7fa98168f15114e5f38bc76df5416bfb3290bd` |
| `records/STATE.md` | record copy | 7847 | `f1472f209dce00f411137395c9008e7b1fbee0538aa1f551806ed213ceaa9420` |
| `records/_project/IMPLEMENTATION_CONTRACT.md` | record copy | 13157 | `3df33d23d025dcbdbbaadb5e8e3352aa9d6489d7d6f14b60081c3830edb0b50e` |
| `records/_project/UI_SPEC.md` | record copy | 23241 | `487151dafe64dd04bc23839acddae55357ccc2d63baab3a8b5b9f1bb180c70a6` |
| `records/session_2026-10-29.md` | record copy | 8087 | `88a035854a4e264a8fc6172d1cb2d0e24555a7b447f87c837a21d5af56822666` |
| `records_cumulative_vs_d6fe678.diff` | cumulative diff vs d6fe678 (ADDENDUM_001 + ADDENDUM_002) | 33612 | `16011258fbec7c22fef54b739ed6fd655821001e97ef6404e9242c8b8d7eb0e7` |
| `source/e2e/public.activation-scenarios.spec.ts` | changed-source copy (working tree) | 9612 | `7900cb61324d3d2bd8d51a318ebda8cc6e99b6ecca91893d81e3eb570cc00ba8` |
| `source/src/__tests__/portal-checkout-hold.test.tsx` | changed-source copy (working tree) | 9470 | `3da94760d540d89e321bfe8520d0706f6ae2de268f7673fc55fea9455022c205` |
| `source/src/components/portal/PublicDemoControls.tsx` | changed-source copy (working tree) | 5574 | `0fb1c16e24e4d7ea361cdfad22bdbc9e0f348553e207937c3b474703429695c4` |
