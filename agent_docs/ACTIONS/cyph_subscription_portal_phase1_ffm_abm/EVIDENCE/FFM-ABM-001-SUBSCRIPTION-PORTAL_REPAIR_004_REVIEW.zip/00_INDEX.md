# FFM-ABM-001-SUBSCRIPTION-PORTAL: REPAIR_004 review package (RULINGS R-013 addendum 1)
29 October 2026 (Asia/Dhaka) · Engineer: Claudy · Authorized by JARVIS. **Engineering self-check, not QA certification.** Running Cody's probes here is engineering evidence.
- **Base:** `qa/ffm-abm-001-subscription-portal` @ `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36`, plus uncommitted R-012 addenda 1/2 and REPAIR_003 (preserved).
- **Input:** Cody's REPAIR_003 RETEST_001 (SHA-256 `ef9097bd…d436`).
- **Findings:** R3-F01 (legacy v2 open checkout rebound to edited scope), R3-F02 (completed activation named a later admin), R3-O03 (dark focus ring 2.99:1 on a tinted alert). Self-found and **not repaired**: R4-N01 (report §6).

| Path | What it is |
|---|---|
| `REPAIR_004_ENGINEERING_REPORT.md` | Preflight, reproduction, root causes, repair, validation, R4-N01, limitations, changed paths |
| `REPAIR_004/BEFORE_AFTER.md` | The same instruments before and after, including run attempts that were corrected |
| `REPAIR_004/REPAIR_004_incremental.diff` | Exact code diff of this repair on top of REPAIR_003 (9 files: 6 product, 3 test) |
| `REPAIR_004/REPAIR_004_records_incremental.diff` | Exact diff of the records changed by this repair (10 files) |
| `REPAIR_004/cumulative_vs_d6fe678.diff` | Exact code diff of addenda + REPAIR_003 + REPAIR_004 vs `d6fe678` (`src`, `e2e`, including new files) |
| `REPAIR_004/source/` | Full copies of every changed product and test file |
| `REPAIR_004/before/` · `REPAIR_004/after/` | Logs, JSON and JSONL: Cody's service, browser and focus probes and their fixtures; new Jest and spec; build; tsc; full Jest; affected regression (and `after/regression-run1/`); R4-N01 observation |
| `REPAIR_004/data/` | Gate M, contrast and focus JSONL from the final affected run; pre-repair source hashes |
| `REPAIR_004/screenshots/` | Unmatched stand-in and completed activation at 375/1440 in light and dark; focused restore ring in both themes; Cody's probe screenshots before/after; R4-N01 |
| `REPAIR_004/probes/` | How Cody's probes were installed (path substitutions), his two configs, and the R4-N01 observation sources |
| `REPAIR_004/CLEANUP_AND_LIMITATIONS.md` | Process/auth cleanup and known limits |
| `records/` | RULINGS (R-013 addendum 1), ACCEPTANCE_SPEC v1.5, ACCEPTANCE_LEDGER, DATA_CONTRACT v1.6, UI_SPEC, ENGINEERING_HANDOFF §9, STATE, JOURNAL, RECOVERY, CHANGELOG |
| `FILE_INDEX.json` | SHA-256 and size of every other member |

Excluded by design: credentials, auth state, env files, browser profiles, `node_modules`, build output, nested archives.
