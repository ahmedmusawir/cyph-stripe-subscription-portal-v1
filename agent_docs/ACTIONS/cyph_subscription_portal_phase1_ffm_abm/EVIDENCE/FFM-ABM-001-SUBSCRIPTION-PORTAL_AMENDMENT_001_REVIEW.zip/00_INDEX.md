# FFM-ABM-001-SUBSCRIPTION-PORTAL — AMENDMENT_001 review package index (RULINGS R-011)

Owner-only registration with explicit owner declaration (Coach decision; Director authorization). Engineering self-checks only — not QA certification.
Branch `qa/ffm-abm-001-subscription-portal`, base HEAD `0d43a4c343909467487b327e654e0650b21c9336` (REPAIR_001 committed); amendment uncommitted, pending Director commit.
Start with `AMENDMENT_001_ENGINEERING_REPORT.md`. Privacy: credential values and real display name scanned — 0 hits (planted control 4, clean control 0).

| Member | Role | Bytes | SHA-256 |
|---|---|---|---|
| `AMENDMENT_001/AMENDMENT_001_product.diff` | product diff vs 0d43a4c (tracked + new files) | 38432 | `12e7e43884cc44b5070a6f0b3879d93a50dceb840804cb6d6970798d86397381` |
| `AMENDMENT_001/AMENDMENT_001_records.diff` | ruling/contract/AC/handoff diff vs 0d43a4c | 24014 | `46355e78d51771a0d2799422155788b5facf1fa4086003c1a437cb456e6fce40` |
| `AMENDMENT_001/data/contrast-account.jsonl` | measured data | 70920 | `884ac44f8c08e853a247a03f5438dea6efd3243ac12e351ddbbe98cec155f39c` |
| `AMENDMENT_001/data/contrast-public.jsonl` | measured data | 131371 | `66ca46ffcd4561be53046a9ff3b5f51743309ca74e507d44910144273d04908e` |
| `AMENDMENT_001/data/gate-m-account.jsonl` | measured data | 9624 | `93f1125a06b111b093a76e118ff03a79248ce0633aabc82a258c96d9b683c6fd` |
| `AMENDMENT_001/data/gate-m-public.jsonl` | measured data | 16024 | `e1119d5d05ce3f21fe21960549e6592e89ae51f6c3393b8d23dfd69180b60f0b` |
| `AMENDMENT_001/data/jest.json` | measured data | 62720 | `ffb84c8b8c52d7ffed5a7ccb14a5e7257c704fc828929e29de9008189443a797` |
| `AMENDMENT_001/data/signin-count.txt` | measured data | 33 | `6e1b912d1649e6400f34db1706f76111b6b0247de4f48632c8681b58a547e2f2` |
| `AMENDMENT_001/logs/build.log` | command log | 1244 | `bcaad28963f3c580d058c2b0ec6ab3d15d035c4bedfad76a3a667d24466dbb43` |
| `AMENDMENT_001/logs/jest.log` | command log | 333 | `4bfb52f44e0e9695b02317ebe7822abbf58b781fa706a57f930b9d03f7b69085` |
| `AMENDMENT_001/logs/pw-account-1.log` | command log | 4121 | `1d05b671244b73383d25f247497f52044501b5c5fc69fe4b30f4a52d73e2c6bd` |
| `AMENDMENT_001/logs/pw-public-1.log` | command log | 12258 | `8a7b111ab62d58bea28ec243895dac352b93c32a98a566e7061d0e8018632ce0` |
| `AMENDMENT_001/logs/tsc.log` | command log | 35 | `79f067f189819b5f9cda949b3797ec24b14a9c3e75d8c0708681db85e2330b1d` |
| `AMENDMENT_001/screenshots/owner-declaration_error_dark_desktop.png` | screenshot (public screen, synthetic data) | 115384 | `6ec7954a578a365dcb62cd7e84e42613f3727f3ae9c5b9b5ee2ae53b791e18a9` |
| `AMENDMENT_001/screenshots/owner-declaration_error_dark_mobile.png` | screenshot (public screen, synthetic data) | 94605 | `502c1581ce7f12c9ba2a57c9a551ad683c366c5e133696251239c37438756b97` |
| `AMENDMENT_001/screenshots/owner-declaration_error_light_desktop.png` | screenshot (public screen, synthetic data) | 115767 | `3f4d2715e68f899d9e2219399930e0f3f4e1575556d1173cd6c88e92ffd5074e` |
| `AMENDMENT_001/screenshots/owner-declaration_error_light_mobile.png` | screenshot (public screen, synthetic data) | 94814 | `c3cf7942f9272cd6754e02746b5fd6aa3eab670f306b08bee65c2bca4657ebc3` |
| `AMENDMENT_001_ENGINEERING_REPORT.md` | engineering report | 11571 | `e0684bfcc5064716505821d3b204be80bc0bfa9cf8932cac7be4314e99846ebe` |
| `records/ACCEPTANCE_LEDGER.md` | updated record | 6764 | `ca50b7aa46cdd8c4607c87f4e926ff162e3d2b16264d3d350e7ad5d42a8c4030` |
| `records/ACCEPTANCE_SPEC.md` | updated record | 16699 | `c7229a98d44b29a9730df9cb49f8c677a82319d7d62a29cfb6bc6d68a7eebf62` |
| `records/JOURNAL.md` | updated record | 5977 | `47772cd973ef63cbcc6740936f45349b702c8b5cfe8b99afb19812d53dffb371` |
| `records/QAM/ENGINEERING_HANDOFF.md` | updated record | 6310 | `1c0d94e2f6cfbe227c6dae664cff1091f1d6536b383585b71236df290395c16c` |
| `records/RULINGS.md` | updated record | 21606 | `cf600be5ddb2a05ec3e45117f886cc1c1898fa646fbeba54f4375084c849a6bf` |
| `records/STATE.md` | updated record | 5892 | `4fdf8d6880028a4f075d571f67bb929f6d0239d3026927342c4aaf06699968a9` |
| `records/_project/DATA_CONTRACT.md` | updated record | 17913 | `a30440bbbf7307c64425cda5a04f1967fc00fcd1a7c316eba60b13985ab92ff6` |
| `records/_project/UI_SPEC.md` | updated record | 22131 | `4a11b1979f4ee77ac9a28aa3852fdb222985773a56b6ab466710cc1fa9c7cf17` |
| `records/_project/portal-contract.ts` | updated record | 6772 | `a24ade92c7f43a7fd88e5e52284bcf54e3c41ef832561534059fae1d426bf8e3` |
| `records/session_2026-10-29.md` | updated record (session copy predates its ZIP receipt) | 1894 | `18da3099e21f338020dad851ef5b7e8429bec8be49908a97de8cb06b3aadcae1` |
| `source/e2e/gate-m.public.spec.ts` | changed source/test copy | 5809 | `cdffcd8f940a07b842284c66e9db93b0496bd335fc20158fd0da397012a9f795` |
| `source/e2e/public.journeys.spec.ts` | changed source/test copy | 11065 | `4a14cb8929d25d2016aa55b601281ae498a95c1de5fbed9f9d9799726e3aa4d1` |
| `source/e2e/public.owner-declaration.spec.ts` | changed source/test copy | 6141 | `a42c5a9a49646657992bc290a99e05f5d9e734504d48c5cd24ed5ceb91b48d27` |
| `source/src/__tests__/portal-owner.test.tsx` | changed source/test copy | 2908 | `903ede64bd338588afb26683b7a5460f672e7375226acb0d66e77d32dd046763` |
| `source/src/__tests__/portal-registration.test.ts` | changed source/test copy | 21799 | `cfc900d01138b45cfe64319ce58bd132cd948b60cc75ee6bdc6b972617f279b7` |
| `source/src/components/portal/PharmacyFields.tsx` | changed source/test copy | 8265 | `a3c4fd099b2f43fdfe63f09aac88ba676af9a72ba100d1429a17a6b754d17205` |
| `source/src/components/portal/register/OwnerView.tsx` | changed source/test copy | 9156 | `6bc549b25aa3c2afd23ea40f08cae0093b78fba2fce0e156ebb689161f5ecd76` |
| `source/src/components/portal/register/ReviewView.tsx` | changed source/test copy | 21809 | `f81d2d5a3dfb6969ab1805ed93c47a12f192e1e1cee8dff2216e923806acc9f6` |
| `source/src/mocks/portal/fixtures.ts` | changed source/test copy | 5129 | `84b2f703b203b95a829d639d6f58f6107d1acfbf8772db80b6b00c9a9d50ff58` |
| `source/src/services/portal/catalog.ts` | changed source/test copy | 917 | `a9b50a9e5e2af6d58b9fb6b1c1038c4b327863870d7f85590ebdf5e8b3d58cbc` |
| `source/src/services/portal/registration.ts` | changed source/test copy | 29867 | `4f19f94a3a897d2caeaabeb2722e60f984c9e51dbebf6fb963e928d5e7f21539` |
| `source/src/services/portal/registrationService.ts` | changed source/test copy | 6689 | `509ffef3b3efb3b953c7520e34b93dbae06d098df1df4b1c3c2ed612b56e8557` |
| `source/src/services/portal/validation.ts` | changed source/test copy | 3657 | `bccaf4e762a4bfe774465972e39fd5ba2efc22d5f36961a023b20adcee3e5a5c` |
| `source/src/types/portal/contract.ts` | changed source/test copy | 6838 | `9aee22d78b90e10ae887ff4ca0bf191ba6a81732c2983d665061b00914895f51` |
