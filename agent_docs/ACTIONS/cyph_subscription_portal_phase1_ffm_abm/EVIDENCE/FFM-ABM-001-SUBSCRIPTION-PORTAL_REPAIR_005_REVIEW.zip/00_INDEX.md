# FFM-ABM-001-SUBSCRIPTION-PORTAL: REPAIR_005 review package (RULINGS R-014)
30 October 2026 (Asia/Dhaka) · Engineer: Claudy · Authorized by JARVIS. **Engineering self-check, not QA certification.**
- **Base:** `qa/ffm-abm-001-subscription-portal` @ `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36`, plus uncommitted addenda 1/2, REPAIR_003, REPAIR_004 and its addendum 1 (preserved).
- **Input:** Cody's REPAIR_004 RETEST_001 (SHA-256 `8f2dff8c…74b3`).
- **Closes (engineering):** R4-F01 (stale refresh confirmed a nothing-charged record) and R4-F02 (unknown record with a stale failed flag was discarded by resume).

| Path | What it is |
|---|---|
| `REPAIR_005_ENGINEERING_REPORT.md` | Preflight, reproduction, root cause, repair, validation, changed paths |
| `REPAIR_005/TRANSITION_MATRIX.md` | 8 checkout records × 4 activation flags × 7 actions, with the phase and outcome of every cell |
| `REPAIR_005/BEFORE_AFTER.md` | The same instruments before and after |
| `REPAIR_005/REPAIR_005_incremental.diff` | Exact code diff on top of REPAIR_004 ADDENDUM_001 (6 files: 3 product, 3 test) |
| `REPAIR_005/REPAIR_005_records_incremental.diff` | Exact diff of the records changed by this repair (10 files) |
| `REPAIR_005/cumulative_vs_d6fe678.diff` | Exact code diff of everything uncommitted vs `d6fe678` |
| `REPAIR_005/source/` | Full copies of every changed product and test file |
| `REPAIR_005/before/` · `after/` | Logs, JSON and JSONL: Cody's probes and observations, new Jest and spec, build, tsc, full Jest, affected regression |
| `REPAIR_005/data/` | Matrix JSON, Gate M, contrast and focus JSONL, pre-repair source hashes |
| `REPAIR_005/screenshots/` | The two new C06 notices at 375/1440 light/dark; Cody's probe screenshots before/after |
| `REPAIR_005/probes/` | How Cody's probes were installed (substitutions) and his two configs |
| `REPAIR_005/CLEANUP_AND_LIMITATIONS.md` | Process/auth cleanup and known limits |
| `records/` | RULINGS (R-014), ACCEPTANCE_SPEC v1.7, ACCEPTANCE_LEDGER, DATA_CONTRACT v1.8, UI_SPEC, ENGINEERING_HANDOFF §9, STATE, JOURNAL, RECOVERY, CHANGELOG |
| `FILE_INDEX.json` | SHA-256 and size of every other member |

Excluded by design: credentials, auth state, env files, browser profiles, `node_modules`, build output, nested archives.
