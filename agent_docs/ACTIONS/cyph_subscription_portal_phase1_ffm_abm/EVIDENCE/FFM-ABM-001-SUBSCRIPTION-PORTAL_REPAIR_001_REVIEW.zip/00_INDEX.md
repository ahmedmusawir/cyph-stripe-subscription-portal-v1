# FFM-ABM-001-SUBSCRIPTION-PORTAL — REPAIR_001 review package index

Engineering handoff for independent retest (RULINGS R-010). Not QA certification. Candidate: uncommitted tree on `qa/ffm-abm-001-subscription-portal` @ 94251be (pending Director commit).
Start with `REPAIR_001_ENGINEERING_REPORT.md`. Privacy: credential values and the real display name were scanned for: 0 hits (planted control 4 hits, clean control 0).

| Member | Role | Bytes | SHA-256 |
|---|---|---|---|
| `REPAIR_001/REPAIR_001_product.diff` | repair diff vs 94251be | 89333 | `a91cb0d9aa69afd171da46826ab17b3e568bd5f5bf26459d03578aec3822857a` |
| `REPAIR_001/data/after-contrast-account.jsonl` | measured data | 70920 | `f8d66de94af7c8cf9a457a18106a3954ff07db2f30f8feb52f91ffc122f1dae0` |
| `REPAIR_001/data/after-contrast-public.jsonl` | measured data | 131957 | `be9630e7a7b0364320825a3b69dc121eef403d02456f70d8d174e46bb6b5b5e9` |
| `REPAIR_001/data/before-contrast-account.jsonl` | measured data | 60110 | `20b9889a32385402a22aa5ffca821c5c46c968026403e4053f61159ba13a3894` |
| `REPAIR_001/data/before-contrast-public.jsonl` | measured data | 168856 | `2a926f262afc478f474e70ea842c21133ffe95afaf49930ad7941b51828c3a84` |
| `REPAIR_001/data/contrast-summary.json` | measured data | 1961 | `3ac89b483251d006ceb34db9bc8d0ea4761e45f43b012d00ac4f2dc0eae5db48` |
| `REPAIR_001/data/final-jest.json` | measured data | 56898 | `0764e061b70e11f9a38ae3908bc4e81f46430eca6314b022ecc42beaffef9536` |
| `REPAIR_001/data/final-pw.json` | measured data | 138878 | `04974fc187138de0313977c01f96c55c17ae0ec79ba74cd900080f64065b6c5c` |
| `REPAIR_001/data/gate-m-account.jsonl` | measured data | 9624 | `93f1125a06b111b093a76e118ff03a79248ce0633aabc82a258c96d9b683c6fd` |
| `REPAIR_001/data/gate-m-public.jsonl` | measured data | 16024 | `e1119d5d05ce3f21fe21960549e6592e89ae51f6c3393b8d23dfd69180b60f0b` |
| `REPAIR_001/data/query-probe.txt` | measured data | 931 | `ead816bb5823a7ca86d712f31d93dce25d5bed8f84f2666f51259a144e72685d` |
| `REPAIR_001/data/signin-count.txt` | measured data | 33 | `6e1b912d1649e6400f34db1706f76111b6b0247de4f48632c8681b58a547e2f2` |
| `REPAIR_001/logs/after-account-1.log` | command log | 6012 | `b63525a44b12b8d767768272471d947d824cd726852e849527e24548e84d0a90` |
| `REPAIR_001/logs/after-account-2.log` | command log | 1630 | `02d516a49b40160b5aedf52db18ff90ec68f099a135b6571ba042329ce306f18` |
| `REPAIR_001/logs/after-public-1.log` | command log | 41763 | `460a25d1bbad337ec96433da8c34ff9ec0625a1c3aa70c0c5108d1194348f102` |
| `REPAIR_001/logs/after-public-2.log` | command log | 6035 | `b69960ce1decf81033766c9456ed917a2f7822f3191372b8907397988b18a815` |
| `REPAIR_001/logs/baseline-build.log` | command log | 1244 | `9450a1588b18a8897482d660c91ffe146c6756cd5107998db8654e6bf9a182a2` |
| `REPAIR_001/logs/before-account.log` | command log | 146137 | `ba49b24c5b051ea37b52d5bb70f2f2f1b5f97e76fd1ef3a814f74ad837c85305` |
| `REPAIR_001/logs/before-public.log` | command log | 345644 | `517211dea1dfc10e1bebc1780498e41aed6c97ea7a137adcd1e7b83cd079ec7c` |
| `REPAIR_001/logs/build.log` | command log | 1244 | `43c91b5d23b1ab4c08b251fdedf89fe38e972cf82fc0131374fbba32405c3432` |
| `REPAIR_001/logs/final-jest.log` | command log | 324 | `4d24cbe0f6f13d8182ea45fe39555685f38cfb1a182ecd587639859e9ee2ec44` |
| `REPAIR_001/logs/final-pw.log` | command log | 15779 | `860ee83bc438fda4c62508434a456f2a12860d6e2a4e1c56b46ae9966c1f825a` |
| `REPAIR_001/logs/tsc.log` | command log | 35 | `79f067f189819b5f9cda949b3797ec24b14a9c3e75d8c0708681db85e2330b1d` |
| `REPAIR_001/screenshots/repair-account-billing_active_dark_mobile.png` | masked screenshot | 138347 | `308bf950234938504ebb5c9d47a2c266929305a725815d63542df987c5d5d9ee` |
| `REPAIR_001/screenshots/repair-account-billing_active_light_mobile.png` | masked screenshot | 139732 | `fefb7a95bf81e0839a78b0edd07349eacc604fd4252b21a1577015b34e3b34d1` |
| `REPAIR_001_ENGINEERING_REPORT.md` | engineering report | 18891 | `3f8a15b4e21205215acac7f68956b4a022e51bcc45089cc5ad2f0f8d3a20f923` |
| `records/JOURNAL.md` | module/session record (session copy predates its ZIP receipt) | 5422 | `0630914f3801d768ff4ff58511dc9b756474b20e551ec33503ea6270ba0a70eb` |
| `records/RULINGS.md` | module/session record (session copy predates its ZIP receipt) | 17566 | `1b56d95823ae037abe04a7b3aae3c3249d15290156429ed74323f025a9cacf61` |
| `records/STATE.md` | module/session record (session copy predates its ZIP receipt) | 5118 | `262095cce36d1c141e9ed11efbdc2e1f3e87398949224430c631010920a5dd16` |
| `records/session_2026-10-28.md` | module/session record (session copy predates its ZIP receipt) | 3277 | `122c9f3475a150ed4b70900395323e43f4b4f7b27ab398b8d38755c2f111f00f` |
| `tests/e2e/account.journeys.spec.ts` | test / classifier source copy | 10977 | `b2f0134deafff74626c238e6cacdff47eae5bca10ac63de48e2401f97fb2f55a` |
| `tests/e2e/account.repair.spec.ts` | test / classifier source copy | 16794 | `9ff46780342c5ec5c9eb043a9dc947dd565c60bbf524cea68418c6839a7c43d0` |
| `tests/e2e/auth.ts` | test / classifier source copy | 2129 | `d075b6b17029490d183ed194306add901883f3a42e21b3e81a44879a63a09f70` |
| `tests/e2e/contrast.ts` | test / classifier source copy | 7984 | `718f13b143f6789f9f2b6ab44717c0a05675fad43d68695b0fc8ff376b57ab6a` |
| `tests/e2e/logout.final.spec.ts` | test / classifier source copy | 1123 | `0127f90c4bca6ef1391e0e3d683b9ce2145b4bf5954e9a361619a13bcc53e896` |
| `tests/e2e/public.repair.spec.ts` | test / classifier source copy | 7955 | `e755d01dee0e9b35da5dab9c742cd83a38676c5bdce344026afb855c75c5cc39` |
| `tests/e2e/public.zoom.spec.ts` | test / classifier source copy | 1201 | `d9c9211bc1e0e9cd62b75a2b8600daab7ac6d519ca24e804024468b585f17e5d` |
| `tests/playwright.config.ts` | test / classifier source copy | 1486 | `4fb6ce9f892c06aebf30fe8e790fd33a97ba7daa65a70daa2212526d8e5facc5` |
| `tests/src/__tests__/portal-account.test.ts` | test / classifier source copy | 13020 | `ec3b3d1fc8f5459f69a83f16c52659daf534da751c8b12f371d1c9a0c5db6c99` |
| `tests/src/__tests__/portal-dashboard.test.tsx` | test / classifier source copy | 3269 | `6a1460085ed8d5dddab543f33f5a8d14311b34cf0ec6fc105dc479f10dfb8067` |
| `tests/src/__tests__/portal-registration.test.ts` | test / classifier source copy | 17648 | `257fae19bd7a408a085ce4e839bafcb84b72731375442b16ea8e997b93cb4693` |
| `tests/src/__tests__/portal-stripe-route.test.tsx` | test / classifier source copy | 4961 | `4dd0c4a5811fb17aff28cc0efb7ccfab054c05bc08759737c47320f0618f1693` |
| `tests/src/services/portal/stripeRoute.ts` | test / classifier source copy | 1590 | `4c7ebf509e80850645a75a43ee489b20a77326dfa138c496d5da1ab79f47d5fd` |
