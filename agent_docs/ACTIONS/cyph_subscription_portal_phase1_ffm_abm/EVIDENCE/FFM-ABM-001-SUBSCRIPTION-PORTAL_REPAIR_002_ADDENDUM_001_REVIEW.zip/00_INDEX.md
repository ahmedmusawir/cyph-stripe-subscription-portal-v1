# FFM-ABM-001-SUBSCRIPTION-PORTAL — REPAIR_002 addendum 1 package index (R-012 addendum 1)

Manual-review copy fix: C14 unknown-payment introduction. Base `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36` (Director commit of REPAIR_002); addendum uncommitted. Engineering self-check only — not QA certification.
Start with `REPAIR_002_ENGINEERING_REPORT.md` §10. Machine index: `FILE_INDEX.json` (every member except itself).

| Member | Role | Bytes | SHA-256 |
|---|---|---|---|
| `REPAIR_002_ENGINEERING_REPORT.md` | report (see §10) | 21682 | `2814f2ddae086762fd4a0e996f7028b4362ec753b4a5af4632307f1644267d6e` |
| `addendum_001/ADDENDUM_001_product.diff` | scoped diff vs d6fe678 | 5877 | `2dbe3e012f6e65badf53886748499bdef44bc1be6262a123f2f1a69e7c8eb6b9` |
| `addendum_001/ADDENDUM_001_records.diff` | scoped diff vs d6fe678 | 14356 | `34f67c8a8319f542e76057fa4056b0df69777c2ab52c84d5b6581a698233a257` |
| `addendum_001/data/contrast-c14-intro.jsonl` | measured data | 1176 | `3ae6ef06d883a5228e1949643fc364788fc3e025e1c03fa14708ec15a1215862` |
| `addendum_001/data/gate-m-c14-intro.jsonl` | measured data | 1692 | `5de4fce64bb9a834a48cd88346952703760c83fd691e11817cebef328fb5c246` |
| `addendum_001/data/jest.json` | measured data | 76712 | `0267f79a652bd18d79a00f173d5916a61744729ab915a1f932e01fa84d8600d7` |
| `addendum_001/logs/build.log` | command log | 1251 | `2fe46399f2a4b2e3b9c0b815310183e30ab78ae0be942bb6861b299c5099e49a` |
| `addendum_001/logs/jest.log` | command log | 276 | `1f0f27f2281b021df3ededb37cc5b08c8c2b1b6a0708696c56b70198f8d5fcb1` |
| `addendum_001/logs/pw-c14.log` | command log | 1014 | `c8b116b5d8333d2c725c41aab4b637b0f83d18378c0d627013b4c0bd186639ab` |
| `addendum_001/screenshots/c14-intro-checkout_abandoned_dark_1440.png` | screenshot (public screen, synthetic data) | 86922 | `2352906b78c3425c65a34f81467a1bc1b98c8e32c1be82ee0771f6fd53e1c747` |
| `addendum_001/screenshots/c14-intro-checkout_abandoned_dark_375.png` | screenshot (public screen, synthetic data) | 76482 | `1fd398998a72c8f2b3f23c3fad60a2469a9b976e4e31c95e3879d62187fa7ab2` |
| `addendum_001/screenshots/c14-intro-checkout_abandoned_light_1440.png` | screenshot (public screen, synthetic data) | 86419 | `59fd2ce0810b81e3cda6d875c97f2459460e392a68ae0f41c8e04459e012675e` |
| `addendum_001/screenshots/c14-intro-checkout_abandoned_light_375.png` | screenshot (public screen, synthetic data) | 76293 | `25006ebdd604343ef4164466b255496acd139676534c14e63ec98144bcc62cd8` |
| `addendum_001/screenshots/c14-intro-checkout_declined_dark_1440.png` | screenshot (public screen, synthetic data) | 87251 | `0ecc42e68b800b6a1e87a2a5fc2e829674ccc83236d7b1ac2d476320ff6a2c4d` |
| `addendum_001/screenshots/c14-intro-checkout_declined_dark_375.png` | screenshot (public screen, synthetic data) | 75909 | `c9a790335af9177b6347c7cc238adf8e05d2a2cd948d7a0557028de67bac8c6e` |
| `addendum_001/screenshots/c14-intro-checkout_declined_light_1440.png` | screenshot (public screen, synthetic data) | 86753 | `a9b520c033396bce72f4a7401c03d736837bb7aa9b1027f1e2817485f47776bb` |
| `addendum_001/screenshots/c14-intro-checkout_declined_light_375.png` | screenshot (public screen, synthetic data) | 75843 | `9f5ea2a3634829294c0d00907f4db665cac87d646026e4dda4e824fbe0b9d34d` |
| `addendum_001/screenshots/c14-intro-checkout_unknown_dark_1440.png` | screenshot (public screen, synthetic data) | 106373 | `4538ed72927aa7ecebdfee6cd3cafdf11531c767836d0f44fcc68dda85062f13` |
| `addendum_001/screenshots/c14-intro-checkout_unknown_dark_375.png` | screenshot (public screen, synthetic data) | 97292 | `cb3e8b277f2ad40dc6005dd27b91e4a633aa0a08f92ce6ead18b5f9e6aa0b2ba` |
| `addendum_001/screenshots/c14-intro-checkout_unknown_light_1440.png` | screenshot (public screen, synthetic data) | 106122 | `95e7ecaed25f3c50e6aaba5e2a46b9440a78a08b2a4af32ee4d068f2cfed955f` |
| `addendum_001/screenshots/c14-intro-checkout_unknown_light_375.png` | screenshot (public screen, synthetic data) | 97060 | `737a05e5ce49edd22930d6f77ab31572ed1d56a046aada5f55f7b3b626f8987f` |
| `records/CHANGELOG.md` | record copy | 4280 | `61932fa9ce1391338dcf6012f1c45b4242c8c95d350b835ca160b8dde59e0472` |
| `records/JOURNAL.md` | record copy | 7094 | `a59e1a035b33d164ae91eeb37884e878916d48f9827e156d6e253e362a6402d8` |
| `records/QAM/ENGINEERING_HANDOFF.md` | record copy | 7690 | `ca450d0df0097cd661312e427b5f0c7697f2aad264e8295bb804a7a9ffa5bd5b` |
| `records/RECOVERY.md` | record copy | 6277 | `5d16f08f11491081060a7a2cb9c6e1dd1094431ac9f846af5feda5bd3dc043e0` |
| `records/RULINGS.md` | record copy | 27491 | `a60c7f47a33e29673e9a91cb4daabb01b9633fd1e14c55dfa543c06905a867eb` |
| `records/STATE.md` | record copy | 7366 | `f0b599909a755000b5984e3e49210156ee5ff7932192be69ad8e7c05b956757d` |
| `records/_project/UI_SPEC.md` | record copy | 22863 | `1968d9d19e4bb364a9cf7985fab67022bdc15faddcef23b2d5096ef3f4a70c73` |
| `records/session_2026-10-29.md` | record copy | 6500 | `b4c91cf3f47765fe1baee26da1359065effa04f0cf42748ac41486dca82a18ee` |
| `source/e2e/public.repair002.spec.ts` | changed file (working tree) | 23894 | `b393f7dcd89678f6c95237297bd035f0a5bc9cffcd4ef318902d6c1b47cf6bf8` |
| `source/src/__tests__/portal-checkout-hold.test.tsx` | changed file (working tree) | 8515 | `845abe560284a6ca1da889a3a8f5abf045e80c96617bb283244714e34962f02d` |
| `source/src/components/portal/activation/CheckoutIncompleteView.tsx` | changed file (working tree) | 7884 | `2c593a77ee214e8dc915080da0142dc597e532d90f61869f75731e19b460ff7a` |
