# REVIEW START HERE — FFM-ABM-001-SUBSCRIPTION-PORTAL · E1 review 001
27 Oct 2026 · Engineer: Claudy · repo HEAD `1d15918dc20d80476d6a3cb017b10179f3ddf783` (main, == foundation)

1. `repo/agent_docs/RESPONSES/…e1-review…md` is the one-page summary (same text as on screen).
2. `module/EXECUTION_PLAN.md` is the plan for approval: exceptions X1–X3, amendment A-1, blockers B1–B4 (§8–9).
3. `module/EVIDENCE/E1_RECON.md` holds the facts and commands. `INSTALL_RECORD.md` + `INSTALLED_FILE_MANIFEST.json` record the installation and current hashes. `FILE_INDEX.json` is the original, unchanged.
4. `module/RULINGS.md` R-007 records the Director's ACTIONS relocation.
5. Unchanged contracts are included for reference (FFM_ENTRY, ACCEPTANCE_SPEC, IMPLEMENTATION_CONTRACT).

Decision needed: Director approval of the plan (record exact instruction) + resolutions for B1 branch, B2 Supabase project identity, B3 reviewer identity, B4 PID 40320.
No product code changed. No Git mutation. No network auth request. Engineering claims only; not QA.
