# FFM-ABM-001-SUBSCRIPTION-PORTAL: REPAIR_004 ADDENDUM_001 review package (RULINGS R-013 addendum 2)
29 October 2026 (Asia/Dhaka) · Engineer: Claudy · Authorized by JARVIS. **Engineering self-check, not QA certification.**
- **Base:** `qa/ffm-abm-001-subscription-portal` @ `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36`, plus uncommitted addenda 1/2, REPAIR_003 and REPAIR_004 (preserved).
- **Incremental on REPAIR_004:** that package (`…_REPAIR_004_REVIEW.zip`, SHA-256 `96075846…4464`) is unchanged.
- **Closes:** R4-N01 (a submitted payment could be discarded from Review and paid again) and the completed-legacy display limitation.

| Path | What it is |
|---|---|
| `REPAIR_004_ADDENDUM_001_ENGINEERING_REPORT.md` | Preflight, reproduction, root cause, repair, validation, limitations, changed paths |
| `REPAIR_004_ADDENDUM_001/BEFORE_AFTER.md` | The same instruments before and after, including the corrected spec attempt |
| `REPAIR_004_ADDENDUM_001/ADDENDUM_001_incremental.diff` | Exact code diff on top of REPAIR_004 (11 files: 8 product, 3 test) |
| `REPAIR_004_ADDENDUM_001/ADDENDUM_001_records_incremental.diff` | Exact diff of the records changed by this addendum (10 files) |
| `REPAIR_004_ADDENDUM_001/cumulative_vs_d6fe678.diff` | Exact code diff of everything uncommitted vs `d6fe678` (`src`, `e2e`, including new files) |
| `REPAIR_004_ADDENDUM_001/source/` | Full copies of every changed product and test file |
| `REPAIR_004_ADDENDUM_001/before/` · `after/` | Logs and JSON: new Jest, new spec (both attempts), R4-N01 observation, build, tsc, full Jest, affected regression |
| `REPAIR_004_ADDENDUM_001/data/` | Gate M, contrast and focus JSONL from the final affected run; pre-addendum source hashes |
| `REPAIR_004_ADDENDUM_001/screenshots/` | Review submitted notice, stand-in submitted notice and unavailable history at 375/1440 in light and dark; R4-N01 before/after |
| `REPAIR_004_ADDENDUM_001/CLEANUP_AND_LIMITATIONS.md` | Process/auth cleanup |
| `records/` | RULINGS (R-013 addendum 2), ACCEPTANCE_SPEC v1.6, ACCEPTANCE_LEDGER, DATA_CONTRACT v1.7, UI_SPEC, ENGINEERING_HANDOFF §9, STATE, JOURNAL, RECOVERY, CHANGELOG |
| `FILE_INDEX.json` | SHA-256 and size of every other member |

Excluded by design: credentials, auth state, env files, browser profiles, `node_modules`, build output, nested archives.
