# FFM-ABM-001-SUBSCRIPTION-PORTAL: REPAIR_006 review package (RULINGS R-014 addendum 1)
30 October 2026 (Asia/Dhaka) · Engineer: Claudy · Authorized by JARVIS. **Engineering self-check, not QA certification.**
- **Base:** `qa/ffm-abm-001-subscription-portal` @ `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36`, plus all uncommitted repairs through REPAIR_005 (preserved).
- **Input:** Cody's REPAIR_005 RETEST_001 (SHA-256 `1d3154c4…93dd`).
- **Closes (engineering):** R5-F01 (C06 rendered stale/absent activation before the payment phase), R5-F02 (resend accepted a stale confirmed flag on non-paid checkouts). **R5-O03** recorded per the Lead, not repaired.

| Path | What it is |
|---|---|
| `REPAIR_006_ENGINEERING_REPORT.md` | Preflight, reproduction, root cause, repair, validation, changed paths |
| `REPAIR_006/INSPECTED_PATHS.md` | Every consumer of payment/activation state inspected: changed, already consistent, or reported |
| `REPAIR_006/BEFORE_AFTER.md` | The same instruments before and after |
| `REPAIR_006/REPAIR_006_incremental.diff` | Exact code diff on top of REPAIR_005 (7 files: 3 product, 4 test) |
| `REPAIR_006/REPAIR_006_records_incremental.diff` | Exact diff of the records changed (10 files) |
| `REPAIR_006/cumulative_vs_d6fe678.diff` | Exact code diff of everything uncommitted vs `d6fe678` |
| `REPAIR_006/source/` | Full copies of every changed product and test file |
| `REPAIR_006/before/` · `after/` | Logs/JSON/JSONL: Cody's oracle and reader probes with fixtures and observations, new Jest and spec, build, tsc, full Jest, focused and full regression |
| `REPAIR_006/data/` | Gate M, contrast JSONL; pre-repair source hashes |
| `REPAIR_006/screenshots/` | Paid-status-unavailable notice at 375/1440 light/dark; Cody's reader screenshots before/after |
| `REPAIR_006/probes/` | Probe installation (substitutions) and Cody's two configs |
| `REPAIR_006/CLEANUP_AND_LIMITATIONS.md` | Process/auth cleanup and known limits |
| `records/` | RULINGS (R-014 addendum 1), ACCEPTANCE_SPEC v1.8, ACCEPTANCE_LEDGER, DATA_CONTRACT v1.9, UI_SPEC, ENGINEERING_HANDOFF §9, STATE, JOURNAL, RECOVERY, CHANGELOG |
| `FILE_INDEX.json` | SHA-256 and size of every other member |

Excluded by design: credentials, auth state, env files, browser profiles, `node_modules`, build output, nested archives.
