# FFM-ABM-001-SUBSCRIPTION-PORTAL — REPAIR_003 review package (RULINGS R-013)
29 October 2026 (Asia/Dhaka) · Engineer: Claudy · Authorized by JARVIS. **Engineering self-check, not QA certification.**
Base: `qa/ffm-abm-001-subscription-portal` @ `d6fe67839961fcbbf801b0bb04d3a2522e7b1f36` + uncommitted R-012 addenda 1/2 (preserved). Input: Cody's REPAIR_002 RETEST_001 (SHA-256 `a38718e2…bd80`).

| Path | What it is |
|---|---|
| `REPAIR_003_ENGINEERING_REPORT.md` | Preflight, before-repair reproduction, root cause, repair, validation, limitations, cleanup, changed paths |
| `REPAIR_003/BEFORE_AFTER.md` | The same instruments before and after |
| `REPAIR_003/REPAIR_003_incremental.diff` | Exact diff of this repair on top of the addenda (13 files) |
| `REPAIR_003/cumulative_vs_d6fe678.diff` | Exact diff of addenda + R-013 vs `d6fe678` (`src`, `e2e`) |
| `REPAIR_003/source/` | Full copies of every changed product and test file |
| `REPAIR_003/before/` · `REPAIR_003/after/` | Logs, JSON and JSONL: Jest, Cody's service and browser files, new spec, build, tsc, affected regression |
| `REPAIR_003/data/` | Gate M and contrast JSONL from the affected run |
| `REPAIR_003/screenshots/` | Scope holds (activation, checkout-incomplete, stand-in) at 375/1440 light/dark; Cody's repro before/after |
| `REPAIR_003/CLEANUP_AND_LIMITATIONS.md` | Process/auth cleanup and known limits |
| `records/` | RULINGS (R-013), ACCEPTANCE_SPEC v1.4, ACCEPTANCE_LEDGER, DATA_CONTRACT v1.5, UI_SPEC, ENGINEERING_HANDOFF §9, STATE, JOURNAL, RECOVERY, CHANGELOG |
| `FILE_INDEX.json` | SHA-256 and size of every other member |

Excluded by design: credentials, auth state, env files, `node_modules`, build output, nested archives.
